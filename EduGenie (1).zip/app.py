from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sympy import symbols, sympify, solve

app = FastAPI(title="EduGenie")

x = symbols("x")


class Question(BaseModel):
    question: str
    subject: str


@app.get("/", response_class=HTMLResponse)
def home():
    with open("Index.html", "r", encoding="utf-8") as file:
        return file.read()


@app.post("/ask")
def ask_question(data: Question):

    question = data.question.strip()
    subject = data.subject
    question_lower = question.lower()


    # =========================
    # STUDY / QUIZ MODE
    # =========================

    if "quiz" in question_lower or "practice" in question_lower:

        if subject == "python":
            return {
                "answer": """📚 Python Quiz

Question:
Which keyword is used to define a function in Python?

A) function
B) def
C) fun
D) define

Answer: B) def"""
            }

        elif subject == "html":
            return {
                "answer": """📚 HTML Quiz

Question:
Which HTML tag is used to create a paragraph?

A) <h1>
B) <p>
C) <br>
D) <div>

Answer: B) <p>"""
            }

        elif subject == "math":
            return {
                "answer": """📚 Mathematics Quiz

Question:
What is 5 × 6?

A) 20
B) 25
C) 30
D) 35

Answer: C) 30"""
            }

        elif subject == "computer":
            return {
                "answer": """📚 Computer Science Quiz

Question:
What does CPU stand for?

A) Central Processing Unit
B) Computer Personal Unit
C) Central Program Utility
D) Computer Processing User

Answer: A) Central Processing Unit"""
            }

        else:
            return {
                "answer": "Please choose a subject before starting a quiz."
            }


    # =========================
    # MATHEMATICS
    # =========================

    if subject == "math":

        try:
            equation = question_lower

            equation = equation.replace("what is", "")
            equation = equation.replace("solve", "")
            equation = equation.replace("calculate", "")
            equation = equation.replace("×", "*")
            equation = equation.replace("÷", "/")
            equation = equation.strip()

            if "=" in equation:

                left, right = equation.split("=")

                left = left.replace("x", "*x")

                left = sympify(left)
                right = sympify(right)

                result = solve(left - right, x)

                if result:
                    return {
                        "answer": f"Answer: x = {result[0]}"
                    }

                return {
                    "answer": "I couldn't solve that equation."
                }

            result = sympify(equation)

            return {
                "answer": f"Answer: {result}"
            }

        except Exception:

            return {
                "answer": "I couldn't understand that math problem."
            }


    # =========================
    # PYTHON
    # =========================

    if subject == "python":

        if "add two numbers" in question_lower:

            return {
                "answer": """Python program to add two numbers:

a = 10
b = 20

sum = a + b

print("The sum is:", sum)"""
            }

        elif "variable" in question_lower:

            return {
                "answer": """A variable is used to store data in Python.

Example:

name = "John"
age = 20"""
            }

        elif "loop" in question_lower:

            return {
                "answer": """A loop repeats a block of code.

Example:

for i in range(5):
    print(i)"""
            }

        elif "hello world" in question_lower:

            return {
                "answer": """Python program:

print("Hello, World!")"""
            }

        elif "if" in question_lower:

            return {
                "answer": """An if statement is used to make decisions in Python.

Example:

age = 18

if age >= 18:
    print("Adult")"""
            }

        else:

            return {
                "answer": "Python is a programming language used for AI, web development, automation and data science."
            }


    # =========================
    # HTML
    # =========================

    if subject == "html":

        if "button" in question_lower:

            return {
                "answer": """HTML code to create a button:

<button>Click Me</button>"""
            }

        elif "heading" in question_lower:

            return {
                "answer": """HTML code to create a heading:

<h1>Hello World</h1>"""
            }

        elif "paragraph" in question_lower:

            return {
                "answer": """HTML code to create a paragraph:

<p>This is a paragraph.</p>"""
            }

        elif "link" in question_lower:

            return {
                "answer": """HTML code to create a link:

<a href="https://example.com">Visit Website</a>"""
            }

        elif "image" in question_lower:

            return {
                "answer": """HTML code to add an image:

<img src="image.jpg" alt="My Image">"""
            }

        elif "table" in question_lower:

            return {
                "answer": """HTML code to create a table:

<table>
    <tr>
        <th>Name</th>
        <th>Age</th>
    </tr>

    <tr>
        <td>John</td>
        <td>20</td>
    </tr>
</table>"""
            }

        elif "form" in question_lower:

            return {
                "answer": """HTML code to create a form:

<form>
    <label>Name:</label>
    <input type="text">

    <button type="submit">Submit</button>
</form>"""
            }

        else:

            return {
                "answer": "HTML stands for HyperText Markup Language. It is used to create and structure webpages."
            }


    # =========================
    # COMPUTER SCIENCE
    # =========================

    if subject == "computer":

        if "cpu" in question_lower:

            return {
                "answer": """CPU stands for Central Processing Unit.

It is the main processing unit of a computer. It executes instructions, performs calculations and controls other operations."""
            }

        elif "ram" in question_lower:

            return {
                "answer": """RAM stands for Random Access Memory.

It temporarily stores data and programs that are currently being used by the computer."""
            }

        elif "algorithm" in question_lower:

            return {
                "answer": """An algorithm is a step-by-step procedure used to solve a problem or complete a task.

Example:

1. Start
2. Enter two numbers
3. Add the numbers
4. Display the result
5. Stop"""
            }

        elif "database" in question_lower:

            return {
                "answer": """A database is an organized collection of data that can be stored, managed and retrieved.

Example:
A college database can store student names, roll numbers, courses and marks."""
            }

        elif "operating system" in question_lower or "os" in question_lower:

            return {
                "answer": """An Operating System (OS) is system software that manages computer hardware and software resources.

Examples:
Windows, Linux, macOS and Android."""
            }

        elif "artificial intelligence" in question_lower or question_lower == "what is ai" or " ai " in question_lower:

            return {
                "answer": """Artificial Intelligence (AI) is technology that enables computers to perform tasks that normally require human intelligence.

Examples:
Voice assistants, recommendation systems, image recognition and chatbots."""
            }

        elif "internet" in question_lower:

            return {
                "answer": """The Internet is a worldwide network that connects computers and devices so they can communicate and share information."""
            }

        elif "hardware" in question_lower:

            return {
                "answer": """Hardware refers to the physical parts of a computer that can be seen and touched.

Examples:
Keyboard, mouse, monitor, CPU and RAM."""
            }

        elif "software" in question_lower:

            return {
                "answer": """Software is a set of programs and instructions that tell a computer what to do.

Examples:
Web browsers, games, operating systems and mobile applications."""
            }

        elif "computer" in question_lower:

            return {
                "answer": """A computer is an electronic device that accepts data, processes it and produces useful information.

Basic functions:
Input → Processing → Output → Storage"""
            }

        else:

            return {
                "answer": """Computer Science is the study of computers, programming, algorithms, data and computational systems.

You can ask me about CPU, RAM, algorithms, databases, operating systems, AI, hardware or software."""
            }


    # =========================
    # NO SUBJECT
    # =========================

    return {
        "answer": "Please choose a subject first."
    }